# Code_Source_Pipeline_MLOps_Docker.zip

Livrable certifié du Cabinet Rabiou Saley.
Client : Client Général
Expert Référent : Abdoul Majid Rabiou Saley
WhatsApp : +227 96 49 99 06
Portfolio : https://mon-portfolio-fin-ten.vercel.app/